# Malicious-Multitool
Im new to coding and wanted to make a multitool with features that everybody needs. 
Add my discord @10101011010101001 

Includes 

1. IP pinger
2. Webhook Deleter
3. Webhook Spammer
4. Webhook Checker
5. Discord Nuker
6. Port Scanner

And more updates will be added once I get better and more comfortable with python as its coded with python

USAGE...

Download the zip 

Extract the zip file

Open the MultiTool( for linux use: python3 Malicious-MultitoolV1.0.5.py)

Will ask for display name(display name doesnt effect anything)

And enjoy the tool
